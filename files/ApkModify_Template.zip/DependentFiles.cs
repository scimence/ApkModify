﻿
using $safeprojectname$.Properties;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class DependentFiles
    {
        /// <summary>
        /// 获取当前运行路径
        /// </summary>
        public static string curDir()
        {
            return AppDomain.CurrentDomain.BaseDirectory;
        }

        /// <summary>
        /// 获取当前运行路径下的tools目录
        /// </summary>
        public static string toolsDir()
        {
            return AppDomain.CurrentDomain.BaseDirectory + $safeprojectname$.Apktool.toolsDir + "\\";
        }

        /// <summary>
        /// 检测目录是否存在，若不存在则创建
        /// </summary>
        public static void checkDir(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        /// <summary>
        /// 保存Byte数组为文件
        /// </summary>
        public static void SaveFile(Byte[] array, string path, bool repalce = false)
        {
            if (repalce && System.IO.File.Exists(path)) System.IO.File.Delete(path);    // 若目标文件存在，则替换
            if (!System.IO.File.Exists(path))
            {
                // 创建输出路径
                String dir = System.IO.Path.GetDirectoryName(path);
                checkDir(dir);

                // 创建输出流
                System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Create);

                //将byte数组写入文件中
                fs.Write(array, 0, array.Length);
                fs.Close();
            }
        }

        //=============================================

        /// <summary>
        /// 检测所有依赖文件，没有则生成
        /// </summary>
        public static void checksAll()
        {
            check("signapk");
            check("signer");
            check("zipalign");
            checkSigns();
        }

        /// <summary>
        /// 检测文件是否存在，不存在则创建
        /// </summary>
        public static void check(string name)
        {
            string tools = curDir() + $safeprojectname$.Apktool.toolsDir;
            checkDir(tools);
            tools += "\\";

            if (name.Equals("signapk")) SaveFile(Resources.signapk, tools + "signapk.jar");
            else if (name.Equals("signer")) SaveFile(Resources.signer, tools + "signer.jar");
            else if (name.Equals("zipalign")) SaveFile(Resources.zipalign, tools + "zipalign.exe");
        }

        /// <summary>
        /// 检查签名是否存在，不存在则创建
        /// </summary>
        public static void checkSigns()
        {
            string signs = curDir() + "\\" + $safeprojectname$.Apktool.toolsDir + "\\signs";
            checkDir(signs);
            signs += "\\";

            SaveFile(Resources._default, signs + "default.keystore");
        }

        /// <summary>
        /// 为arg添加引号
        /// </summary>
        private static string AddQuotation(string arg)
        {
            if (arg.EndsWith("\\") && !arg.EndsWith("\\\\")) arg += "\\";
            arg = "\"" + arg + "\"";

            return arg;
        }

    }
}
