﻿namespace $safeprojectname$
{
    partial class MainFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainFrom));
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_sign = new System.Windows.Forms.ComboBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Modify = new System.Windows.Forms.Button();
            this.checkBox_SignAll = new System.Windows.Forms.CheckBox();
            this.labelAllSign = new System.Windows.Forms.Label();
            this.dirDest = new System.Windows.Forms.TextBox();
            this.checkBox_bat = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 36;
            this.label1.Text = "游戏包：";
            // 
            // comboBox_sign
            // 
            this.comboBox_sign.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_sign.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_sign.FormattingEnabled = true;
            this.comboBox_sign.Location = new System.Drawing.Point(354, 15);
            this.comboBox_sign.Name = "comboBox_sign";
            this.comboBox_sign.Size = new System.Drawing.Size(96, 20);
            this.comboBox_sign.TabIndex = 35;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox1.Location = new System.Drawing.Point(14, 70);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(521, 270);
            this.richTextBox1.TabIndex = 34;
            this.richTextBox1.Text = "";
            // 
            // Modify
            // 
            this.Modify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Modify.Location = new System.Drawing.Point(459, 15);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(75, 43);
            this.Modify.TabIndex = 33;
            this.Modify.Text = "修改";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // checkBox_SignAll
            // 
            this.checkBox_SignAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_SignAll.AutoSize = true;
            this.checkBox_SignAll.Location = new System.Drawing.Point(354, 45);
            this.checkBox_SignAll.Name = "checkBox_SignAll";
            this.checkBox_SignAll.Size = new System.Drawing.Size(48, 16);
            this.checkBox_SignAll.TabIndex = 37;
            this.checkBox_SignAll.Text = "选中";
            this.checkBox_SignAll.UseVisualStyleBackColor = true;
            // 
            // labelAllSign
            // 
            this.labelAllSign.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelAllSign.AutoSize = true;
            this.labelAllSign.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelAllSign.ForeColor = System.Drawing.Color.Blue;
            this.labelAllSign.Location = new System.Drawing.Point(399, 46);
            this.labelAllSign.Name = "labelAllSign";
            this.labelAllSign.Size = new System.Drawing.Size(53, 12);
            this.labelAllSign.TabIndex = 40;
            this.labelAllSign.Text = "所有签名";
            this.labelAllSign.Click += new System.EventHandler(this.labelAllSign_Click);
            // 
            // dirDest
            // 
            this.dirDest.AllowDrop = true;
            this.dirDest.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dirDest.Location = new System.Drawing.Point(71, 15);
            this.dirDest.Multiline = true;
            this.dirDest.Name = "dirDest";
            this.dirDest.Size = new System.Drawing.Size(274, 46);
            this.dirDest.TabIndex = 41;
            this.dirDest.DragDrop += new System.Windows.Forms.DragEventHandler(this.dirDest_DragDrop);
            this.dirDest.DragEnter += new System.Windows.Forms.DragEventHandler(this.dirDest_DragEnter);
            // 
            // checkBox_bat
            // 
            this.checkBox_bat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox_bat.AutoSize = true;
            this.checkBox_bat.Location = new System.Drawing.Point(472, 341);
            this.checkBox_bat.Name = "checkBox_bat";
            this.checkBox_bat.Size = new System.Drawing.Size(66, 16);
            this.checkBox_bat.TabIndex = 42;
            this.checkBox_bat.Text = "bat模式";
            this.checkBox_bat.UseVisualStyleBackColor = true;
            this.checkBox_bat.CheckedChanged += new System.EventHandler(this.checkBox_bat_CheckedChanged);
            // 
            // MainFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 358);
            this.Controls.Add(this.checkBox_bat);
            this.Controls.Add(this.dirDest);
            this.Controls.Add(this.labelAllSign);
            this.Controls.Add(this.checkBox_SignAll);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox_sign);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Modify);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainFrom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ApkModify (apk解包修改工具)";
            this.Load += new System.EventHandler(this.MainFrom_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_sign;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.CheckBox checkBox_SignAll;
        private System.Windows.Forms.Label labelAllSign;
        private System.Windows.Forms.TextBox dirDest;
        private System.Windows.Forms.CheckBox checkBox_bat;
    }
}