﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApkModifyInfos
{
    public partial class MainFrom : Form
    {
        public MainFrom()
        {
            InitializeComponent();
            dirDest.Text = ApkProcessLogic.toolTipInfo;
        }

        private void MainFrom_Load(object sender, EventArgs e)
        {
            ApkProcessLogic.loadSigns(comboBox_sign);      // 载入签名文件信息

            LoadParam();
        }

        private void dirDest_DragEnter(object sender, DragEventArgs e)
        {
            ApkProcessLogic.Form_DragEnter(sender, e);
        }

        private void dirDest_DragDrop(object sender, DragEventArgs e)
        {
            ApkProcessLogic.Form_DragDrop(sender, e);
        }

        private void labelAllSign_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe", "/e, " + Apktool.toolsDir + @"\signs");
        }

        private void checkBox_bat_CheckedChanged(object sender, EventArgs e)
        {
            Cmd.useBatMode = checkBox_bat.Checked;
        }

        private void Modify_Click(object sender, EventArgs e)
        {
            RecordPraram();

            // 执行apk修改逻辑
            ApkProcessLogic.Modify_Click(this, Modify, richTextBox1, dirDest.Text, comboBox_sign.Text, Modify_Logic, checkBox_SignAll.Checked);
        }

        private static void OutPut(String info)
        {
            ApkProcessLogic.OutPut(info);
        }

        /// <summary>
        /// 执行修改逻辑
        /// </summary>
        private void Modify_Logic()
        {
            //OutPut("附加广告id信息log输出逻辑...");

            String path = ApkProcessLogic.unpackPath;
            if (path.Equals("")) return;

            ModifyLogic.ModifyProcess(path, OutPut);
        }

        /// <summary>
        /// 修改apkTool.yml中的指定项值
        /// </summary>
        private String modifyValueSet(String data0, String key, String value)
        {
            String data = data0;

            // targetSdkVersion: '26'
            String keyS = key + ":";
            if (data.Contains(keyS))
            {
                int indexS = data.IndexOf(keyS);
                int indexE = data.IndexOf("'", indexS + keyS.Length);
                if (indexE != -1)
                {
                    indexE = data.IndexOf("'", indexE + 1);
                    if (indexE != -1)
                    {
                        indexE = indexE + 1;
                        String keySetStr = data.Substring(indexS, indexE - indexS);
                        String newSetStr = keyS + " '" + value + "'";

                        data = data.Replace(keySetStr, newSetStr);

                        OutPut("【I】修改" + keySetStr + " -> " + newSetStr);
                    }
                }
            }
            return data;
        }

        /// <summary>
        /// 记录参数信息
        /// </summary>
        private void RecordPraram()
        {
            String apkPath = dirDest.Text.Trim();
            RegistryTool.RegistrySave(UpdateTool.NAMESPACE, "apkPath", apkPath);
        }

        private void LoadParam()
        {
            String apkPath = RegistryTool.RegistryStrValue(UpdateTool.NAMESPACE, "apkPath");
            dirDest.Text = apkPath;
        }

    }
}
