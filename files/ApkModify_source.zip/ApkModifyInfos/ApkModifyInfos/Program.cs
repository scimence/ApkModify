﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApkModifyInfos
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            UpdateTool.AutoUpdate();                        // 应用自动检测更新
            ApkModifyInfos.DependentFiles.checksAll();      // 检测工具运行依赖文件

            Application.Run(new MainFrom());                // 显示修改工具主界面
        }

        //使用说明：
        //1、重写函数 ModifyLogic.ModifyProcess(path, OutPut); 实现需要修改的逻辑即可。
        //2、UpdateTool.NAMESPACE 改写名称，指定更新路径
    }
}
